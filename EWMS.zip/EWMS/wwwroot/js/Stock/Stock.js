﻿/* =========================================================
   STOCK MANAGEMENT - JAVASCRIPT (FIXED)
========================================================= */

// ✅ FIX: Khai báo biến global (sẽ được gán giá trị từ Index.cshtml)
let warehouseId;
let selectedRack;

let racksData = [];
let locationsData = [];
let productsData = [];
let selectedLocationId = null;

// Format helpers
function formatNumber(value) {
    return new Intl.NumberFormat('vi-VN').format(value);
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/* =========================================================
   LOAD DATA
========================================================= */

// Load Summary
async function loadSummary() {
    try {
        const response = await fetch(`/Stock/GetStockSummary?warehouseId=${warehouseId}`);
        const data = await response.json();

        if (data.error) {
            console.error('Error:', data.error);
            return;
        }

        document.getElementById('total-locations').textContent = formatNumber(data.totalLocations);
        document.getElementById('total-products').textContent = formatNumber(data.totalProducts);
        document.getElementById('total-stock').textContent = formatNumber(data.totalStock);
        document.getElementById('total-capacity').textContent = formatNumber(data.totalCapacity);
        document.getElementById('utilization-rate').textContent = data.utilizationRate + '%';
    } catch (error) {
        console.error('Load summary failed:', error);
    }
}

// Load Racks
async function loadRacks() {
    try {
        const response = await fetch(`/Stock/GetRacks?warehouseId=${warehouseId}`);
        const data = await response.json();

        if (data.error) {
            console.error('Error:', data.error);
            return;
        }

        racksData = data;
        renderRacks();

        // ✅ Auto select rack từ URL hoặc defaultRack
        if (racksData.length > 0) {
            const rackToSelect = racksData.find(r => r.rack === selectedRack)
                ? selectedRack
                : racksData[0].rack;

            selectedRack = rackToSelect;

            // ✅ FIX: Không dùng setTimeout, gọi trực tiếp
            selectRack(rackToSelect);
        }
    } catch (error) {
        console.error('Load racks failed:', error);
    }
}

// Load Locations by Rack
async function loadLocations(rack) {
    try {
        const container = document.getElementById('locations-container');
        container.innerHTML = `
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Đang tải...</span>
            </div>
        `;

        const response = await fetch(`/Stock/GetLocationsByRack?warehouseId=${warehouseId}&rack=${rack}`);
        const data = await response.json();

        if (data.error) {
            console.error('Error:', data.error);
            container.innerHTML = '<div class="alert alert-danger">Lỗi tải dữ liệu</div>';
            return;
        }

        locationsData = data;
        renderLocations();

        // Auto select first location
        if (locationsData.length > 0) {
            selectedLocationId = locationsData[0].locationId;
            selectLocation(locationsData[0].locationId, locationsData[0].locationCode);
        }
    } catch (error) {
        console.error('Load locations failed:', error);
    }
}

// Load Products by Location
async function loadProducts(locationId, locationCode) {
    try {
        const container = document.getElementById('products-container');
        container.innerHTML = `
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Đang tải...</span>
                </div>
            </div>
        `;

        const response = await fetch(`/Stock/GetProductsByLocation?locationId=${locationId}`);
        const data = await response.json();

        if (data.error) {
            console.error('Error:', data.error);
            container.innerHTML = '<div class="alert alert-danger">Lỗi tải dữ liệu</div>';
            return;
        }

        productsData = data;
        renderProducts();
    } catch (error) {
        console.error('Load products failed:', error);
    }
}

/* =========================================================
   RENDER UI
========================================================= */

// Render Racks
function renderRacks() {
    const container = document.getElementById('racks-container');

    if (racksData.length === 0) {
        container.innerHTML = '<div class="col-12 text-center text-muted">Không có rack nào</div>';
        return;
    }

    container.innerHTML = '';

    racksData.forEach(rack => {
        const utilizationPercent = rack.totalCapacity > 0
            ? Math.round(rack.currentStock / rack.totalCapacity * 100)
            : 0;

        const col = document.createElement('div');
        col.className = 'col-md-3';
        col.innerHTML = `
            <div class="card rack-card ${selectedRack === rack.rack ? 'active' : ''}" 
                 onclick="selectRack('${rack.rack}')">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h3 class="mb-0">Rack ${rack.rack}</h3>
                        <i class="bi bi-grid-3x3-gap-fill text-primary" style="font-size: 2rem;"></i>
                    </div>
                    <div class="mb-2">
                        <small class="text-muted">Số vị trí:</small>
                        <strong class="float-end">${formatNumber(rack.locationCount)}</strong>
                    </div>
                    <div class="mb-2">
                        <small class="text-muted">Tồn kho:</small>
                        <strong class="float-end">${formatNumber(rack.currentStock)} / ${formatNumber(rack.totalCapacity)}</strong>
                    </div>
                    <div class="progress" style="height: 8px;">
                        <div class="progress-bar ${utilizationPercent > 80 ? 'bg-danger' : utilizationPercent > 50 ? 'bg-warning' : 'bg-success'}" 
                             style="width: ${utilizationPercent}%"></div>
                    </div>
                    <small class="text-muted">${utilizationPercent}% đã sử dụng</small>
                </div>
            </div>
        `;
        container.appendChild(col);
    });
}

// Render Locations
function renderLocations() {
    const container = document.getElementById('locations-container');

    if (locationsData.length === 0) {
        container.innerHTML = '<div class="alert alert-info">Không có vị trí nào trong rack này</div>';
        return;
    }

    container.innerHTML = '';

    locationsData.forEach(location => {
        const utilizationPercent = location.capacity > 0
            ? Math.round(location.currentStock / location.capacity * 100)
            : 0;

        const badge = document.createElement('div');
        badge.className = `badge location-badge ${selectedLocationId === location.locationId ? 'active' : ''}`;
        badge.style.cssText = 'padding: 12px 16px; font-size: 0.9rem;';
        badge.onclick = () => selectLocation(location.locationId, location.locationCode);

        let statusColor = 'success';
        if (utilizationPercent > 80) statusColor = 'danger';
        else if (utilizationPercent > 50) statusColor = 'warning';

        badge.innerHTML = `
            <div><strong>${location.locationCode}</strong></div>
            <small class="d-block">${formatNumber(location.currentStock)}/${formatNumber(location.capacity)}</small>
            <small class="badge bg-${statusColor}" style="font-size: 0.7rem;">${utilizationPercent}%</small>
        `;

        container.appendChild(badge);
    });
}

// Render Products
function renderProducts() {
    const container = document.getElementById('products-container');

    if (productsData.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5 text-muted">
                <i class="bi bi-inbox" style="font-size: 4rem;"></i>
                <p class="mt-3">Không có sản phẩm nào trong vị trí này</p>
            </div>
        `;
        return;
    }

    container.innerHTML = '';

    const colors = ['#667eea', '#f093fb', '#4facfe', '#fa709a', '#43e97b'];

    productsData.forEach((product, index) => {
        const card = document.createElement('div');
        card.className = 'card stock-card mb-3';
        card.style.borderLeftColor = colors[index % colors.length];

        card.innerHTML = `
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-1">
                        <div class="text-center">
                            <div class="badge bg-primary" style="font-size: 1.2rem; padding: 12px;">
                                ${product.sku}
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <h6 class="mb-1">${product.productName}</h6>
                        <small class="text-muted">
                            <i class="bi bi-tag"></i> ${product.categoryName}
                        </small>
                    </div>
                    <div class="col-md-2">
                        <small class="text-muted d-block">Vị trí</small>
                        <strong>${product.locationCode}</strong>
                        <small class="text-muted d-block">${product.locationName || ''}</small>
                    </div>
                    <div class="col-md-2">
                        <small class="text-muted d-block">Rack</small>
                        <span class="badge bg-info">${product.rack}</span>
                    </div>
                    <div class="col-md-2">
                        <small class="text-muted d-block">Số lượng tồn</small>
                        <h4 class="mb-0 text-success">${formatNumber(product.quantity)}</h4>
                    </div>
                    <div class="col-md-2">
                        <small class="text-muted d-block">Cập nhật lần cuối</small>
                        <small>${formatDate(product.lastUpdated)}</small>
                    </div>
                </div>
            </div>
        `;

        container.appendChild(card);
    });
}

/* =========================================================
   USER ACTIONS
========================================================= */

function selectRack(rack) {
    selectedRack = rack;
    document.getElementById('current-rack').textContent = `Rack ${rack}`;

    // Update active state
    document.querySelectorAll('.rack-card').forEach(card => {
        card.classList.remove('active');
    });
    
    // ✅ FIX: Tìm và highlight rack đang được chọn
    const activeCard = document.querySelector(`[onclick*="selectRack('${rack}')"]`);
    if (activeCard) {
        activeCard.classList.add('active');
    }

    loadLocations(rack);
}

function selectLocation(locationId, locationCode) {
    selectedLocationId = locationId;
    document.getElementById('current-location').textContent = locationCode;

    // Update active state
    document.querySelectorAll('.location-badge').forEach(badge => {
        badge.classList.remove('active');
    });
    
    // ✅ FIX: Highlight location badge đang được chọn
    // Vì onclick dùng arrow function nên không cần dùng event.currentTarget
    const activeBadge = Array.from(document.querySelectorAll('.location-badge'))
        .find(b => b.querySelector('strong')?.textContent === locationCode);
    if (activeBadge) {
        activeBadge.classList.add('active');
    }

    loadProducts(locationId, locationCode);
}

async function refreshAll() {
    await Promise.all([
        loadSummary(),
        loadRacks()
    ]);
}

/* =========================================================
   INIT
========================================================= */
document.addEventListener('DOMContentLoaded', async () => {
    console.log('Stock Management initialized for warehouse:', warehouseId);
    console.log('Default rack:', selectedRack);

    // ✅ FIX: Kiểm tra warehouseId trước khi load
    if (!warehouseId || warehouseId === 0) {
        console.error('ERROR: warehouseId is not defined!');
        alert('Lỗi: Không xác định được kho!');
        return;
    }

    await refreshAll();
});